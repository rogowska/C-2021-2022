/*Oliwia Rogowska*/
int print_matrix(int, int, int**);