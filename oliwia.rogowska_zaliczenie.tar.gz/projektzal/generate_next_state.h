/*Oliwia Rogowska*/
int generate_next_state(int, int, int, int**);