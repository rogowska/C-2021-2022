/*Oliwia Rogowska*/
int count_neighbours(int, int, int, int, int**);