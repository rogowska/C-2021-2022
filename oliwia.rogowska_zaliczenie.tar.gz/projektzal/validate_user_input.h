/*Oliwia Rogowska*/
int validate_user_input(int*, int*, int*, int*, int, char**);